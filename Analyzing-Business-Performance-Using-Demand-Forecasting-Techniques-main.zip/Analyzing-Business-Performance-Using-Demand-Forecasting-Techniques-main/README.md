# Analyzing-Business-Performance-Using-Demand-Forecasting-Techniques
We will use this repository for accepting assignment submissions.

## Assignment 1
Deadline: 11.59 PM, 19 May, 2023
Instructions:

- Submit all the three jupyter notebooks.
- Every file should be named according to the following convention:
[Roll_Number]_[First Name]
- Push your files into the Exercise 0X folder of Assignment 1.                                                                                                               Eg. Exercise 01 in Assignment 1 -> Exercise 01 and similarly other files.

## Assignment 2
Deadline: 11.59 PM, 23 May, 2023
Instructions:

- Submit the jupyter notebooks.
- Every file should be named according to the following convention:
[Roll_Number]_[First Name]
- Push your files into the Exercise 0X folder of Assignment 2.                                                                                                               Eg. Exercise 01 in Assignment 2 -> Exercise 01 and similarly other files.

## Assignment 3
Deadline: 11.59 PM, 1 June, 2023
Instructions:

- Submit all the solution jupyter notebooks.
- Every file should be named according to the following convention:
[Roll_Number]_[First Name]
- Push your files into the Exercise 0X folder of Assignment 3.                                                                                                               Eg. Exercise 01 in Assignment 3 -> Exercise 01 and similarly other files.


## Final Assignment 
Deadline: 11:59 PM, 22 July, 2023
Instructions:

- Submit all the solution jupyter notebook along with the analysis PPT.
- Every file should be named according to the following convention:
[Team_Number]_[Leader_Alloted]
- Push your files into the Final Assignment folder.