## FINAL ASSIGNMENT

There are 4 companies - Bigg Bazar, D-Mart, Spar and Seven Eleven.

There are 7 stores of each company in Delhi, Mumbai, Kolkata, Lucknow, Banglore, Indore, Jaipur.

Each store has 6 departments which are Beverages, Groceries, Electronics, Clothing & Apparel, Furniture, and Book & Stationary

You have been given over 2 years of company sales data, where weekly data represent the sales of that week and is holiday represents whether the week had any major holidays. You need to predict the sales for the next 6 months using the various times series techniques taught (ofc not limited to, can explore more for sure)

Also we have not provided the name of departments in the dataset so it's your responsibility to go through the trends and guess which department sets the trend best.

For example, winter clothes ( bringing the example back XD) , it's sale will increase in winters so you can check that from the trend. 

Using that sales data you need to understand and explain the behavior of each store and suggest ways to improve and increase business performance. 

Go ahead, Analyzing Business Performance Using Demand Forecasting Techniques.

All the best